import { getDeliveryById } from "@/Modules/Delivery/Features/services/delivery.actions";
import Image from "next/image";
export default async function page({
  params,
}: {
  params: Promise<{ taskId: string }>;
}) {
  const { taskId } = await params;
  const result = await getDeliveryById(taskId);
  return (
    <div>
      {/* menu top  */}
      <div className="breadcrumbs text-sm">
        <ul>
          <li>
            <a>الرئيسية</a>
          </li>
          <li>
            <a>المهام الحالية</a>
          </li>
          <li>{taskId}</li>
        </ul>
      </div>
      {/* Mission details */}
      <div className="rounded-xl bg-linear-to-r to-brand-mid from-brand-primary p-4 flex items-center my-3 text-white gap-3">
        <div className="rounded-full p-3 bg-white/10 backdrop-blur-md border border-white/20">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={1.5}
            stroke="currentColor"
            className="size-12">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="m21 7.5-9-5.25L3 7.5m18 0-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-9v9"
            />
          </svg>
        </div>
        <div>
          <p className="text-gray-300">
            رقم المهمة : <span className="text-white">{taskId}</span>{" "}
          </p>
          <p>تفاصيل المهمة</p>
          <p>
            أنت حالياً في طريقك إلى المالك لاستلام المنتج. تأكد من فحصه قبل
            التوقيع على الاستلام.
          </p>
        </div>
      </div>
      <div className="flex gap-4">
        <div className="border border-gray-400 px-3 py-3 rounded-2xl">
          <div>
            <Image
              src={result.delivery.delivery.productCoverImage}
              alt="productImage"
              height={100}
              width={100}
              className="w-80 h-80"
            />
          </div>

          <div className="bg-accent-light text-warning px-2 py-2 rounded-2xl">
            <h1>ملاحظات التعامل</h1>
            <p className="text-black">
              {result.delivery?.delivery.handlingNotes}
            </p>
          </div>
        </div>

        <div>
          <div className="border border-gray-400 px-3 py-3 rounded-2xl"></div>{" "}
          <div className="border border-gray-400 px-3 py-3 rounded-2xl">
            <h3 className="font-black">ملخص مالي</h3>
            <div className="flex justify-between">
              <p>سعر التأمين</p>
              <p className="font-black">
                {result.delivery.delivery.insuranceAmount}
              </p>
            </div>
            <div className="flex justify-between">
              <p> باقي الحساب</p>
              <p className="font-black">
                {" "}
                {result.delivery.delivery.remainingAmount}
              </p>
            </div>
            <div className="flex justify-between">
              <p> نسبة المنصة (7.5%)</p>
              <p className="font-black">
                {result.delivery.delivery.commissionFee}
              </p>
            </div>
            <div className="flex justify-between text-brand-primary bg-gray-50 rounded-xl">
              <p> الاجمالي</p>
              <p className="font-black"></p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex gap-4 my-5">
        {/* Owner Info */}
        <div className="card w-100 bg-base-100 card-lg shadow-sm px-3">
          <div className="flex justify-between my-3 ">
            <p className=" ">معلومات المالك</p>
            <p className="badge text-brand-primary bg-brand-light ">
              الاستلام أولاً
            </p>
          </div>
          <div className="flex gap-3 items-center">
            <div className="avatar">
              {result?.delivery?.Delivery?.ownerImage ? (
                <div className="w-24 rounded-full">
                  <Image
                    src={result.delivery.Delivery.ownerImage}
                    alt="userImage"
                    width={100}
                    height={100}
                  />
                </div>
              ) : (
                <div className="avatar avatar-placeholder">
                  <div className="bg-neutral text-neutral-content w-20 rounded-full">
                    <span className="text-2xl">
                      {result.delivery.delivery.ownerName[0]}
                    </span>
                  </div>
                </div>
              )}
            </div>
            <p>{result.delivery.delivery.ownerName}</p>
          </div>
          <div className="flex gap-4 my-1 not-only:">
            <p>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="size-4 inline">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z"
                />
              </svg>{" "}
              الهاتف{" "}
            </p>
            <p>{result.delivery.delivery.ownerPhoneNumber}</p>
          </div>
          <div className="flex gap-4 my-1">
            <p>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="size-4 inline">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
                />
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1 1 15 0Z"
                />
              </svg>
              العنوان
            </p>
            <p>
              شارع{result.delivery.delivery.ownerLocation.street}
              مبني رقم
              {result.delivery.delivery.ownerLocation.building}
              دور
              {result.delivery.delivery.ownerLocation.floor}
              علامة مميزة
              {result.delivery.delivery.ownerLocation.mark}
            </p>
          </div>
          <button type="button" className="py-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="size-4 inline">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z"
              />
            </svg>{" "}
            اتصال{" "}
          </button>
        </div>
        {/* renter Info */}
        <div className="card w-100 bg-base-100 card-lg shadow-sm px-3 ">
          <div className="flex justify-between my-3">
            <p> معلومات المستأجر</p>
            <p className="badge text-brand-primary bg-brand-light ">
              {" "}
              التسليم لاحقا
            </p>
          </div>
          <div className="flex gap-3 items-center">
            <div className="avatar">
              {result?.delivery?.Delivery?.ownerImage ? (
                <div className="w-24 rounded-full">
                  <Image
                    src={result.delivery.Delivery.ownerImage}
                    alt="userImage"
                    width={100}
                    height={100}
                  />
                </div>
              ) : (
                <div className="avatar avatar-placeholder">
                  <div className="bg-neutral text-neutral-content w-20 rounded-full">
                    <span className="text-2xl">
                      {result.delivery.delivery.ownerName[0]}
                    </span>
                  </div>
                </div>
              )}
            </div>
            <p>{result.delivery.delivery.ownerName}</p>7
          </div>
          <div className="flex gap-4 my-1">
            <p>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="size-4 inline">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z"
                />
              </svg>{" "}
              الهاتف{" "}
            </p>
            <p>{result.delivery.delivery.renterPhoneNumber}</p>
          </div>
          <div className="flex gap-4 my-1">
            <p>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="size-4 inline">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
                />
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1 1 15 0Z"
                />
              </svg>
              العنوان
            </p>
            <p>
              شارع{result.delivery.delivery.renterLocation.street}
              مبني رقم
              {result.delivery.delivery.renterLocation.building}
              دور
              {result.delivery.delivery.renterLocation.floor}
              علامة مميزة
              {result.delivery.delivery.renterLocation.mark}
            </p>
          </div>
          <button type="button" className="py-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="size-4 inline">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z"
              />
            </svg>{" "}
            اتصال{" "}
          </button>
        </div>
      </div>
    </div>
  );
}
